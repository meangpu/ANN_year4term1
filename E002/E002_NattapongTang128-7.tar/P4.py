"""
P4
Student name: Nattapong Tangsatheanrapap
613040128-7
"""


def gmax(u0, lr, N):
    u_now = u0

    for i in range(N):
        diff_u = diff_func(u_now)
        u_now += lr*diff_u

    return u_now


def diff_func(x):
    ans = 3-(2*x)
    return ans


if __name__ == "__main__":
    ux = gmax(u0=0, lr=0.2, N=10)
    print(ux)
